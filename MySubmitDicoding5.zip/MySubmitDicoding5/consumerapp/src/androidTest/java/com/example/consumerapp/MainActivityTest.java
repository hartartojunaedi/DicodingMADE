package com.example.consumerapp;

import static org.junit.Assert.*;

public class MainActivityTest {

}